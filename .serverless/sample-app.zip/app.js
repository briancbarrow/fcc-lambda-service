const serverless = require('serverless-http');
const express = require('express');
const mongoHandler = require('./mongoHelpers').handler;
const app = express();


app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.get('/api/info', (req, res) => {
  try {
    mongoHandler({ application: 'sample-app', version: '1.0' })
  res.send({ application: 'sample-app', version: '1.0' });
  }
  catch(e) {
    console.log('THIS IS MY LOG', e)
    res.status(e.status).send(e)
  }
});
app.post('/api/v1/getback', (req, res) => {
  res.send({ ...req.body });
});
// app.listen(3000, () => console.log(`Listening on: 3000`));
module.exports.handler = serverless(app);